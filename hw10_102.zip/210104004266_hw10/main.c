#include<stdio.h>
#include<stdlib.h>
#define STACK_BLOCK_SIZE 10
#define true 1
#define false 0

typedef struct stack{ 
int * array; 
int currentsize ; 
int maxsize;
} stack;



void printrod3(stack * r3);
int push(stack * s, int d); /* the stack array will grow STACK_BLOCK_SIZE entries at
a time */
int pop(stack * s); /* the stack array will shrink STACK_BLOCK_SIZE entries at a
time */
stack * init_return(); /* initializes an empty stack */
int init(stack * s); /* returns 1 if initialization is successful */
void printrod(stack * r1,stack * r2,stack * r3);


int main(){
  int control = true;
  stack * rod1 = init_return();
   stack * rod2 = init_return();
   stack * rod3 = init_return();
  
  int size;
  printf("Please enter size : ");
  scanf("%d",&size);

  rod1->maxsize = size;
  rod2->maxsize = size;
  rod3->maxsize = size;
 
 for (int i = size; i >0 ; i--){


   control = push(rod1,(i));
   if (control == false) printf("something is wrong\n");

  }


  
  //printrod(rod1, rod2,rod3);

    int count = 1; 
   while(rod3->currentsize != rod3->maxsize && rod2->currentsize != rod2->maxsize  ){
      int temp;
        if (count % 3 == 1){
        
       if(size %2==1){
          if (rod1->currentsize == 0 )
        	{
        	temp = pop(rod3);
	    	control = push(rod1, temp);
	    	if (control == false) printf("something is wrong\n");
	    	printf("moving disc %d rod 3 to rod 1\n",temp); 
		 
	       }

         else if (rod3->currentsize == 0 )
	      {   temp = pop(rod1);
		      control = push(rod3, temp);
		      if (control == false) printf("something is wrong\n");
		      printf("moving disc %d rod 1 to rod 3\n",temp); 
		  
	       }

		
	  	 else  if (rod1->array[rod1->currentsize-1] > rod3->array[rod3->currentsize-1]){
			temp = pop(rod3);
			control = push(rod1, temp);
			if (control == false) printf("something is wrong\n");
			printf("moving disc %d rod 3 to rod 1\n",temp); 
	
		   }

	 	  else if (rod1->array[rod1->currentsize-1] <= rod3->array[rod3->currentsize-1]){
		   temp = pop(rod1);
		  control = push(rod3, temp);
		  if (control == false) printf("something is wrong\n");
		   printf("moving disc %d rod 1 to rod 3\n",temp); 
         }
    
        }
        else{
          if (rod1->currentsize == 0 )
        	{
        	temp = pop(rod2);
	    	control = push(rod1, temp);
	    	if (control == false) printf("something is wrong\n");
	    	printf("moving disc %d rod 2 to rod 1\n",temp); 
		 
	       }

         else if (rod2->currentsize == 0 )
	      {   temp = pop(rod1);
		      control = push(rod2, temp);
		      if (control == false) printf("something is wrong\n");
		      printf("moving disc %d rod 1 to rod 2\n",temp); 
		  
	       }

		
	  	 else  if (rod1->array[rod1->currentsize-1] > rod2->array[rod2->currentsize-1]){
			temp = pop(rod2);
			control = push(rod1, temp);
			if (control == false) printf("something is wrong\n");
			printf("moving disc %d rod 2 to rod 1\n",temp); 
	
		   }

	 	  else if (rod1->array[rod1->currentsize-1] <= rod2->array[rod2->currentsize-1]){
		   temp = pop(rod1);
		  control = push(rod2, temp);
		  if (control == false) printf("something is wrong\n");
		   printf("moving disc %d rod 1 to rod 2\n",temp); 
         }
        
        
        
        }
        
      }
		

	 if (count % 3 == 2){
	 if(size %2==1){
		   if (rod1->currentsize == 0 )
        	{
        	temp = pop(rod2);
	    	control = push(rod1, temp);
	    	if (control == false) printf("something is wrong\n");
	    	printf("moving disc %d rod 2 to rod 1\n",temp); 
		 
	       }

       else  if (rod2->currentsize == 0 )
	      {   temp = pop(rod1);
		     control =  push(rod2, temp);
		     if (control == false) printf("something is wrong\n");
		      printf("moving disc %d rod 1 to rod 2\n",temp); 
		  
	       }
		else  if (rod1->array[rod1->currentsize-1] > rod2->array[rod2->currentsize-1]){
		  temp = pop(rod2);
		 control = push(rod1, temp);
		 if (control == false) printf("something is wrong\n");
		  printf("moving disc %d rod 2 to rod 1\n",temp); 
	
        	}

	  else  if (rod1->array[rod1->currentsize-1] <= rod2->array[rod2->currentsize-1]) {
		  temp = pop(rod1);
	      control = push(rod2, temp);
	      if (control == false) printf("something is wrong\n");
	      printf("moving disc %d rod 1 to rod 2\n",temp); 
	
	     }
       }
       else{
           if (rod1->currentsize == 0 )
        	{
        	temp = pop(rod3);
	    	control = push(rod1, temp);
	    	if (control == false) printf("something is wrong\n");
	    	printf("moving disc %d rod 3 to rod 1\n",temp); 
		 
	       }

         else if (rod3->currentsize == 0 )
	      {   temp = pop(rod1);
		      control = push(rod3, temp);
		      if (control == false) printf("something is wrong\n");
		      printf("moving disc %d rod 1 to rod 3\n",temp); 
		  
	       }

		
	  	 else  if (rod1->array[rod1->currentsize-1] > rod3->array[rod3->currentsize-1]){
			temp = pop(rod3);
			control = push(rod1, temp);
			if (control == false) printf("something is wrong\n");
			printf("moving disc %d rod 3 to rod 1\n",temp); 
	
		   }

	 	  else if (rod1->array[rod1->currentsize-1] <= rod3->array[rod3->currentsize-1]){
		   temp = pop(rod1);
		  control = push(rod3, temp);
		  if (control == false) printf("something is wrong\n");
		   printf("moving disc %d rod 1 to rod 3\n",temp); 
         }
    
		 
	}
	
	}

	 if (count % 3 == 0){
	
	if(size%2==1){
	 
	      if (rod2->currentsize == 0 )
        	{
        	temp = pop(rod3);
	    	control = push(rod2, temp);
	    	if (control == false) printf("something is wrong\n");
	    	printf("moving disc %d rod 3 to rod 2\n",temp); 
		 
	       }
       
        else if (rod3->currentsize == 0 )
	      {   temp = pop(rod2);
		    control =   push(rod3, temp);
		    if (control == false) printf("something is wrong\n");
		      printf("moving disc %d rod 2 to rod 3\n",temp); 
		  
	       }
		else if (rod2->array[rod2->currentsize-1] > rod3->array[rod3->currentsize-1]){
		temp = pop(rod3);
		control = push(rod2, temp);
		if (control == false) printf("something is wrong\n");
	    printf("moving disc %d rod 3 to rod 2\n",temp); 
	    }

	  else if (rod2->array[rod2->currentsize-1] <= rod3->array[rod3->currentsize-1])	{
		temp = pop(rod2);
		control = push(rod3, temp);
		if (control == false) printf("something is wrong\n");
		printf("moving disc %d rod 2 to rod 3\n",temp); 
	  }
	
    }else{
    
       if (rod1->currentsize == 0 )
        	{
        	temp = pop(rod2);
	    	control = push(rod3, temp);
	    	if (control == false) printf("something is wrong\n");
	    	printf("moving disc %d rod 2 to rod 3\n",temp); 
		 
	       }

       else  if (rod2->currentsize == 0 )
	      {   temp = pop(rod3);
		     control =  push(rod2, temp);
		     if (control == false) printf("something is wrong\n");
		      printf("moving disc %d rod 3 to rod 2\n",temp); 
		  
	       }
		else  if (rod3->array[rod3->currentsize-1] > rod2->array[rod2->currentsize-1]){
		  temp = pop(rod2);
		 control = push(rod3, temp);
		 if (control == false) printf("something is wrong\n");
		  printf("moving disc %d rod 2 to rod 3\n",temp); 
	
        	}

	  else  if (rod3->array[rod3->currentsize-1] <= rod2->array[rod2->currentsize-1]) {
		  temp = pop(rod3);
	      control = push(rod2, temp);
	      if (control == false) printf("something is wrong\n");
	      printf("moving disc %d rod 3 to rod 2\n",temp); 
	
	     }
       
      
    
    }
	     
	}
   count++;
   
     // printrod(rod1, rod2,rod3);

   
   }



  //printrod(rod1, rod2,rod3);
  printrod3(rod3); //to see final situation of rod 3


return 0;
}


int init(stack * s){

 int control = true;
 
 
 if(s == NULL)
  control = false;
 



 return control;
 



}


stack * init_return(){ 

 
 struct stack * rod = (struct stack *) malloc(sizeof(stack ));
 if(init(rod) == true){
 rod->array = (int*) calloc(STACK_BLOCK_SIZE,sizeof(int));
 rod->currentsize = 0; //seting this to 0 to priventing errors

 }
 else{   
  
  rod = (struct stack *) malloc(sizeof(stack ));
  
 }



  return rod;
}

int pop(stack * s){

 int topop =0;

 if(s->currentsize!=0){
 topop = s->array[s->currentsize-1]; 
   
 int * secondarr = (int*) malloc(sizeof(int)*s->currentsize) ;
 
 for(int i = 0; i < s->currentsize;i++){
 
  secondarr[i]= s->array[i];
 
 }
 
 s->currentsize--;         //shrinking array
 
 
 s->array = (int*) malloc(sizeof(int)*s->currentsize);

 
 for(int i = 0; i < s->currentsize;i++){
 
   s->array[i] = secondarr[i];
 
 }









 
 }
 
 
 
return topop;
}


int push(stack * s, int d){



 
 int * secondarr = (int*) malloc(sizeof(int)*s->currentsize) ;
 
 for(int i = 0; i < s->currentsize;i++){
 
  secondarr[i]= s->array[i];
 
 }
 
 s->currentsize++;        //growing array
 
 
 s->array = (int*) malloc(sizeof(int)*s->currentsize);

 
 for(int i = 0; i < s->currentsize-1;i++){
 
   s->array[i] = secondarr[i];
 
 }

 s->array[s->currentsize-1] = d;
 int control = true;
 if(s->currentsize>=2){
 if(s->array[s->currentsize-1] > s->array[s->currentsize-2]   ) 
   
   control = false;
 
 }
 
 
 
return control;
}


void printrod(stack * r1,stack * r2,stack * r3){ /* works only when you dont use dynamic array (I realized we should use dynamic
array after ı wrote this*/
 
  printf("\n\nrod 1 rod 2 rod 3\n");
 
 for(int i =9 ;i>=0;i--){
  
  
  
  if(r1->array[i] == 0 && r2->array[i]==0 && r3->array[i]!=0 )
     printf("               %d  \n", r3->array[i]);
  
  if(r1->array[i] == 0 && r3->array[i]==0 && r2->array[i]!=0)
     printf("         %d     \n", r2->array[i]);
  
  
  if(r3->array[i] == 0 && r2->array[i]==0 && r1->array[i]!=0)
     printf("  %d  \n", r1->array[i]);
  
  if(r3->array[i] == 0 && r2->array[i]!=0 && r1->array[i]!=0)
     printf("  %d    %d  \n", r1->array[i],r2->array[i]);
  
  if(r3->array[i] != 0 && r2->array[i]!=0 && r1->array[i]==0)
     printf("         %d     %d  \n", r2->array[i],r3->array[i]);
      
   if(r3->array[i] != 0 && r2->array[i]==0 && r1->array[i]!=0)
     printf("  %d            %d  \n", r1->array[i],r3->array[i]);
  
   if(r3->array[i] != 0 && r2->array[i]!=0 && r1->array[i]!=0)
     printf("  %d      %d     %d  \n", r1->array[i],r2->array[i],r3->array[i]);
  
   
  
 }
   
 printf("\n\n");
   
   
 

}




void printrod3(stack * r3){ /* works only when you dont use dynamic array (I realized we should use dynamic
array after ı wrote this*/
 
  printf("\n\nrod 3\n");
 
 for(int i = r3->currentsize-1 ;i>=0;i--){
   printf("%d\n",r3->array[i]);
}   
 printf("\n\n");
   
   
 

}
