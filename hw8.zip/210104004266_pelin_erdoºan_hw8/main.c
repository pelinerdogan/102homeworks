#include <stdio.h>
#include "util.h"



int main(){
  int length;
  int firstElement;
  int histo[9] = {0,0,0,0,0,0,0,0,0};
  printf("Please enter the sequence length : ");
  scanf("%d",&length);
  printf("\nPlease enter the first element: ");
  scanf("%d",&firstElement);
  int loop[length/2];
  int looplen = length/2;
  

  int seq[length];


   generate_sequence ( firstElement,  0,  length, seq);

   printf("\nSequence : { " );
  for(int i =0 ;i<length;i++){

    if(i== length-1){
    printf("%d ",seq[i] );
    }
    else{

      printf("%d, ",seq[i] );

    }
    } 

    printf("} \n\n");

    check_loop_iterative( generate_sequence ,  firstElement, length, loop,  &looplen);

    hist_of_firstdigits( generate_sequence ,  firstElement, length, histo, 0);

    printf("\nHistogram : { " );
  for(int i =0 ;i<9;i++){

    if(i==8){
    printf("%d ",histo[i] );
    }
    else{
 
      printf("%d, ",histo[i] );

    }
}

    printf("} \n");


      

 return 0;   
}