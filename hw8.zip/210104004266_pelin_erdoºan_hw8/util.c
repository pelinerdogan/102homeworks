#include <stdio.h>
#include "util.h"

void generate_sequence (int xs, int currentlen, int seqlen, int *seq){
 
 if(currentlen+1<seqlen  ){
     
   if(xs%2==1){
    seq[currentlen] = xs;
    
    xs = 3*xs + 1;
    currentlen++;
     generate_sequence ( xs,  currentlen,  seqlen, seq);
   }
   
   if(xs%2==0){
       
       seq[currentlen] = xs;
       
    xs = xs /2;
    currentlen++;
    
     generate_sequence ( xs,  currentlen,  seqlen, seq);
     
   }
 }
else {


   if(currentlen+1==seqlen  ){
     seq[currentlen] = xs;
   }
     
    
  

   

 
}

 
}

void check_loop_iterative(void (*f)(int,int,int,int*), int xs, int seqlen, int *loop, int *looplen){
 
 
int seq[seqlen];
int ls,le;

 if(*looplen>=2){
   
    printf("checking loop  with a length of %d...\n" , *looplen);
     
   int control ;
  
   f(xs,0,seqlen,seq);
     
     control =  has_loop( seq,  seqlen,  *looplen,  &ls,  &le);
  
     if(control==0){
        
         printf("\nloop detected with a length of %d\n" , *looplen);
        int count =*looplen-1;
        for(int m = seqlen-1; m>=seqlen-(*looplen);m--){

       loop[count] = seq[m];
       count--;
    

         
        }
         printf("indexes of the loops first apperance %d (first digit) %d (last digit) \n" , ls,le);
         printf("Loop : { " );
          for(int i =0 ;i<*looplen;i++)
            if(i== (*looplen)-1){
           printf("%d ",loop[i] );
             }
            else{

           printf("%d, ",loop[i] );

    }

    printf("} \n");
     }
     else{
         (*looplen)--;
            
         check_loop_iterative( f,  xs,  seqlen, loop,  looplen);



     }

 }

 else{
     *looplen =0;
      printf("no loop detected \n" );
 }

}


int has_loop(int *arr, int n, int looplen, int *ls, int *le){
    int control = 0;
    int first = 0;  
 
   for(int i = n-1; i>=n-(looplen);i--){

       
       if(arr[i] != arr[i-(looplen)]){
       
        control = 1;


       }
      
         
     }

      if (control==0){
       for(int i = n-1; i>=n-(looplen);i--){
        
        if(arr[i-looplen] == arr[i-2*(looplen)] ){
       
        
        *ls = i-2*looplen;
        *le = i-looplen-1;

      

       }
       else{

           if(arr[i] == arr[i-(looplen)] ){
       
        
        *ls = i-looplen;
        *le = i-1;

      

       }

       }


       }

      }
  
   return control;

 }

 


   







void hist_of_firstdigits(void (*f)(int,int,int,int*), int xs, int seqlen, int *h, int digit){
    int seq[seqlen];
     int firstNum;
     int keepgoin = 0;

     if (digit<seqlen){
     f(xs,0,seqlen,seq);
     
     while (keepgoin == 0){
    
      if (seq[digit] >= 10 ){
       
         seq[digit] = seq[digit]/10;
        
      }
      else{

         
         firstNum= seq[digit] %10;
         
         keepgoin = 1;

      }


     }

       switch(firstNum){
  
         case 1 :
          
            h[0]++;


          break;

         case 2 :

            h[1]++;

          break;


         case 3 :
         
          h[2]++;


         break;

         case 4 :

          h[3]++;

          break;
         case 5 :
         
          h[4]++;


          break;

         case 6 :

          h[5]++;

          break;

         case 7 :

          h[6]++;

          break;
         case 8 :
         
          h[7]++;


          break;
         case 9 :

          h[8]++;

          break;









       }

        digit++;
        hist_of_firstdigits(f, xs, seqlen, h, digit);
        

      }

}










