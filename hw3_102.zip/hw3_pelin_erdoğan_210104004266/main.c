#include<stdio.h>
#include<math.h>

int sum (int n1, int n2, int flag);
int multi (int n1, int n2, int flag);
void write_file (int number);
int isprime (int a);
int dividible (int a);
void sort_file ();
void print_file ();

int main(){

  int selec; 
  
  printf("Select operation\n1. Calculate sum/multiplication between two numbers\n2. Calculate prime numbers\n3. Show number sequence in file\n4. Sort number sequence in file\n");

  scanf("%d", &selec);
  
  switch(selec){
  
    
      case 1: {
    
      int n1;
      int n2;
      int flag;
      int choose;
      int answer;
      printf("please enter '0' for sum, '1' for multiplication.\n");
      scanf("%d", &choose);
      
      while(choose > 1 || choose<0){
      
        printf("please enter '0' for sum, '1' for multiplication. \n");
        scanf("%d", &choose);
      
      
      }    
      
     
      printf("please enter '0' to work on even numbers, '1' to work on odd numbers.\n");
      scanf("%d", &flag);
      
        while(flag > 1 || flag<0){
      
        printf("please enter '0' to work on even numbers, '1' to work on odd numbers. \n");
        scanf("%d", &flag);
      
      
      }
      printf("please enter two different numbers\n");
      scanf("%d", &n1);
      scanf("%d", &n2);
      
       while(n2 == n1){
      
        printf("please enter two different numbers\n");
      scanf("%d", &n1);
      scanf("%d", &n2);
      
      
      }    
      
      if (n2<n1){
       
       int temp = n2;
       n2= n1;
       n1 = temp;
      
      
      }
     
      
      if(choose == 1){
      
        answer = multi (n1,  n2,  flag);
        printf("= %d\n" , answer);
        if(answer!=0)
        write_file (answer);
      
      
      
      }    
      
      if (choose == 0) {
      
       answer = sum (n1,  n2,  flag);
       printf("= %d\n" , answer);
       
       if(answer!=0)
       write_file (answer);
      
      
      }
    
    
    
    
    
    
    
      break;
    
    }
    
      case 2: {
    
    
      int primeTest;
      
      printf("please enter an integer: \n");
      scanf("%d", &primeTest);
      
      for(int l = 2 ; l <  primeTest ; l++){
      
       int result = isprime (l);
      
        if(result == 1){
        
         printf("%d is a prime number \n",l);
        
        }
         
         if(result == 0){
         
         int d = dividible(l);   // I had to write a function for divisior 
        
         printf("%d is not a prime number. İt is dividible by %d \n",l,d);
        
        }
        
      
      }
    
    
    
    
    
    
    
    
      break;
    
    }
    
      case 3: {
    
    
    
       print_file ();
    
    
    
    
    
    
    
      break;
    
    }
    
      case 4: {
    
    
       sort_file ();
    
    
    
    
    
    
    
    
      break;
    
    }
  
  
  
  
     default : 
  
  
  
      printf("You entered invalid value. Exiting...");
  
  
  
  
  }







return 0;

}


int multi (int n1, int n2, int flag){

  int multiNum = 1;
  n1++;
  int limit;
  
  if(flag == 0){
  
  
    if ( n2%2 == 0)
         limit = n2-2;
   
    if ( n2%2 == 1)
         limit = n2-1;
    
     while(n1<n2){
     
      
     
      if ( n1%2 == 0){
        
         if ( n1 == limit){
        
        printf("%d  " , n1);
        
        }
        else{
        printf("%d x " , n1);
        }
       
       
        multiNum = multiNum*n1;
       
       
         n1 = n1 + 2;
        
        
       
      
     
      }
      if ( n1%2 == 1){
       
         n1++;
      
      }

  
    }
    
  }
  
  
  if(flag == 1){
  
  
    if ( n2%2 == 1)
         limit = n2-2;
   
    if ( n2%2 == 0)
         limit = n2-1;
  
     while(n1<n2){
     
      
      
        
      if ( n1%2 == 1){
        
        
        multiNum = multiNum*n1;
        
        if ( n1 == limit){
        
        printf("%d  " , n1);
        
        }
        else{
        printf("%d x " , n1);
        }
      
      
        
        n1 = n1 + 2;
        

      
      }
      else{
       
         n1++;
      
      }

  
    }
  
  }
  
 







 return multiNum;



}


int sum (int n1, int n2, int flag){

  int sumNum = 0;
  n1++;
  int limit;
  
  if(flag == 0){
  
  
  
    if ( n2%2 == 0)
         limit = n2-2;
   
    if ( n2%2 == 1)
         limit = n2-1;
  
     while(n1<n2){
     
      
        
        
       if ( n1%2 == 0){
        
        
        if ( n1 == limit){
        
        printf("%d  " , n1);
        
        }
        else{
        printf("%d + " , n1);
        }
      
        sumNum = sumNum+n1;
        
        
        n1 = n1 + 2;
        
      
      
      }
      else{
       
         n1++;
      
      }

  
    }
    
  }
  
  
  if(flag == 1){
  
  
    if ( n2%2 == 1)
         limit = n2-2;
   
    if ( n2%2 == 0)
         limit = n2-1;
  
     while(n1<n2){
     
      
        
       if ( n1%2 == 1){
        
        if ( n1 == limit){
        
        printf("%d  " , n1);
        
        }
        else{
        printf("%d + " , n1);
        }
      
        
        sumNum = sumNum+n1;
        
        
        n1 = n1 + 2;
      
      
        
      
      }
      else{
       
         n1++;
      
      }

  
    }
  
  }
  
 







 return  sumNum ;



}

void write_file (int number){


    FILE *output ;
  
   output = fopen ("result.txt","a");
  
     fprintf(output,"%d ",number);
      
  
    fclose(output);
  



}

int isprime (int a){

 int primeORnot = 1;

   int rootA =  sqrt(a);
  
   
   for( int i = 2 ; i <= rootA ; i++){
   
   
     if ( a % i == 0 && a!=i){
        
        primeORnot = 0;     
     
     }
   
   
   
   
   }








  return primeORnot;


}

int dividible (int a){ // I had to write a function for divisior 

 int dividble =1 ;

   int rootA = sqrt(a);
   
   for( int i = 2 ; i <= rootA ; i++){
   
   
     if ( a % i == 0 && a!=i) {
     
        dividble = i;     
     
     }
   
   
   
   
   }


  return dividble ;


}

void sort_file (){
 
 int count = 0;
 
  
  FILE *input ;
  
  input = fopen ("result.txt","r+");
   
  FILE *output ;
     
  output = fopen ("temp.txt","a");
  
   if(input == NULL){
      printf("There is no file to read");
   }
   else{
   
     int min1,min2,min3,num,numT,pos1,pos2,pos3,posnum,length1,length2,length3,space1,space2,space3, spacenum;
  
         while(!feof(input)){
     
           fscanf(input, "%d " , &numT);

           count++;
   
         }
    
      rewind(input);
      
      
       int temp,temppos,tempspace;
       int a; 
      if(count %3 == 0){
        
        a= count/3 ;
       
       }
      else{
       a = count/3 + 1 ;
       
        }
        
         
       
       for( a ; a>0 ;a--){
   	
      if (count>2){ 
   	
    	 
      rewind(input);
     
    
         fscanf(input, " " );
         space1 = ftell(input);
   	 fscanf(input, "%d" , &min1);
   	 pos1 = ftell(input);
   	 
   	 fscanf(input, " " ); 
         space2 = ftell(input);
   	 fscanf(input, "%d" , &min2);
         pos2 = ftell(input);
         
         fscanf(input, " " );
         space3 = ftell(input);
         fscanf(input, "%d" , &min3);
         pos3 = ftell(input);
 
          
  
      if (min3<min1){
     
       temp = min3;
       
       min3 = min1;
       
       min1 = temp;
       
       temppos = pos3;
       pos3 = pos1;
       pos1 = temppos;
       
      tempspace = space3;
      space3 = space2;
      space2 = tempspace;
       
       
   
   
       }
   
      if (min2<min1){
     
      temp = min2;
      min2 = min1;
      min1 = temp;
   
       temppos = pos2;
       pos2 = pos1;
       pos1 = temppos;
       
      tempspace = space2;
      space2 = space1;
      space1 = tempspace;
   
   
       
   
      }
   
     
     if (min3<min2){
     
      temp = min3;
      min3 = min2;
      min2 = temp;
      
      temppos = pos3;
      pos3 = pos2;
      pos2 = temppos;
      
      tempspace = space3;
      space3 = space2;
      space2 = tempspace;
   
      
      
   
   
     }
   
   
   
       while(!feof(input)){
       
       fscanf(input, " " );
       spacenum = ftell(input);
       
       fscanf(input, "%d" , &num);
      
       posnum = ftell(input);
     
       
     
       
     
        if ( num <min3){
     
         min3 = num;
         pos3 = posnum;
         space3 = spacenum;
         
           if ( num < min2){
     
            min3 = min2;
            min2 = num;
            
            pos3 = pos2;
            pos2 = posnum;
            
            space3 = space2;
            
            space2 = spacenum;
           
           
             if ( num < min1){
     
               min2 = min1;
               min1 = num;
               
               pos2 = pos1;
               pos1 = posnum;
           
               space2 = space1;
               space1 = spacenum;
     
              }
     
           }
    
        }
     
        
   
       
    }
    
    //end of taking numbers
         
  
    
  
      
   if(pos3==space3){
    fprintf(output, "%d %d " , min1,min2);
    count = count-2;
   }
   if(pos2==space2){
    fprintf(output, "%d %d " , min1,min3);
    count = count-2;
   }
    if(pos1==space1){
    fprintf(output, "%d %d " , min2,min3);
    count = count-2;
   }   
   if(pos3==space3 && pos2==space2){
    fprintf(output, "%d" , min1);
    count = count-1;
   }
   if(pos2==space2 && pos1==space1){
    fprintf(output, "%d " ,min3);
    count = count-1;
   }
    if(pos1==space1 && pos3==space3){
    fprintf(output, "%d " , min2);
    count = count-1;
   }    
   if(pos3!=space3 && pos2!=space2 && pos1!=space1){
    fprintf(output, "%d %d %d " , min1,min2,min3);
     count = count-3;
       
    
   }
  
    
    
    length1 = pos1-space1;
    length2 = pos2-space2;
    length3 = pos3-space3;
    
    fseek(input,space1,SEEK_SET);
    for(int i = 0; i<= length1 ;i++){
    fprintf(input, " ");
    }
      fseek(input,space2,SEEK_SET);
      
      for(int i = 0; i<= length2 ;i++){
      fprintf(input, " ");
    }
      fseek(input,space3,SEEK_SET);
       for(int i = 0; i<= length3 ;i++){
       fprintf(input, " ");
     
       }
       
      ;
       
    
       
     }
     else{
     
       if (count==2){
     
        
         
   	 fscanf(input, "%d" , &min1);
   	  
        
   	 fscanf(input, "%d" , &min2);
         
         
          if (min2<min1){
     
          temp = min2;
          min2 = min1;
          min1 = temp;
   
         
         
        
        }
        
         if(min2>min3){
        
         fprintf(output, "%d %d " , min1,min2);
         
         
         }
         
       }
        if (count==1){
     
        
   	 fscanf(input, "%d" , &min1);
   	  
   	  
   	  if(min1>min3){
   	 fprintf(output, "%d " , min1);
        
   
          }
       
   
        }
       
       
     }
   }
     
     
     
     fclose(input);
     fclose(output);
      remove("result.txt");
      rename("temp.txt" , "result.txt" );
  
     printf("sorting is complete\n");
     print_file ();
   
  
  
    
   
 
    
  
  }


}
























void print_file (){
  
  
  int num ;
  
    FILE *input ;
     
  
   input = fopen ("result.txt","r");
   
   
   if(input == NULL){
      printf("There is no file to read ");
   }
   else{
   
      printf("result:");
   
   while(!feof(input)){
    
     fscanf(input, "%d " , &num);
     printf("%d " , num);
    
   
    
   
   }
  
    printf("\n " );
  
    fclose(input);
   
 




}

}
