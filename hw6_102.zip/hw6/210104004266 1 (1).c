#include<stdio.h>
#include <stdlib.h>
#include <time.h>

void printMap (int count1, int count2) ;//prints the game area, use the parameters you will need if any.
int dice (); // returns a random integer in a range of [1,6]
int startGame (); // decides who will start the game.


int  main(){

int c1,c2,d1,d2;
char c = '\n';

c1= 0;

c2 = 0 ;

 printMap (c1,c2) ;
 printf ("To start game players should dice and decide who is going to start first according to it\n") ; 

 int start = startGame ();
 
 while(c1<79 && c2 <63){
 
 if (start == 1){
 
 
 printf("\033[0;33m"); 
 printf("Player 1 press enter to dice\n");
 printf("\033[0m");
 c = getchar();
 if(c = '\n'){
   d1 = dice();
   }
  else{
  
   while(c = '\n'){
   
    printf("\033[0;33m"); 
    printf("Player 1 press enter to dice\n");
    printf("\033[0m");
     c = getchar();
   
   
   }
   
      d1 = dice();
      
  
  } 
   
   printf("\033[0;34m");
   printf("Player 2 press enter to dice\n");
   printf("\033[0m");
   c = getchar();
   if(c = '\n'){
   d2 = dice();
   }
  else{
  
   while(c = '\n'){
   
    printf("\033[0;34m");
    printf("Player 2 press enter to dice\n");
    printf("\033[0m");
     c = getchar();
   
   
   }
   
      d2 = dice();
  
  
  } 
 
 
 
 
 
 }
 else{
 
 
 printf("\033[0;34m");  
 printf("Player 2 press enter to dice\n");
 printf("\033[0m");
 c = getchar();
 if(c = '\n'){
   d2 = dice();
   }
  else{
  
   while(c = '\n'){
   
    printf("\033[0;34m");
    printf("Player 2 press enter to dice\n");
    printf("\033[0m");
     c = getchar();
   
   
   }
   
      d2 = dice();
  
  
  } 
   
   printf("\033[0;33m"); 
   printf("Player 1 press enter to dice\n");
   printf("\033[0m");
   c = getchar();
   if(c = '\n'){
   d1 = dice();
   }
  else{
  
   while(c = '\n'){
   
    printf("\033[0;33m"); 
    printf("Player 1 press enter to dice\n");
    printf("\033[0m");
     c = getchar();
   
   
   }
   
      d1 = dice();
  
  
  } 
 
 
 
 
 
 
 
 
 
 }
   c1 = c1 + d1;
   c2 = c2 + d2;
   printMap (c1,c2) ;
  

  }

 
 





return 0;
}




void printMap (int count1, int count2) {

 char table[15][30];
 

  for(int i = 0;i<15;i++){  //creating empty area
  
     for(int k = 0;k<30 ; k++){
  
  
       if( i == 0){ 
       
          table[i][k] = '+';
       
       }
       
      
       
         if( k == 29){
       
          table[i][k] = '+';
       
       }
       
          if( i == 14){
       
          table[i][k] = '+';
       
       }
       
  
        
          if( k == 0){
       
          table[i][k] = '+';
       
       }
  
         
         
        if( i == 2 && k>1 && k<28){
       
          table[i][k] = '+';
       
       }  
       
        if( i == 12 && k>1 && k<28){
       
          table[i][k] = '+';
       
       }
       
       
        if( i == 4 && k>3 && k<26){
       
          table[i][k] = '+';
       
       }
       
       if( i == 10 && k>3 && k<26){
       
          table[i][k] = '+';
       
       }
       if( k == 4 && i>3 && i<13){
       
          table[i][k] = '+';
       
       }
        if( k == 27 && i>2 && i<13){
       
          table[i][k] = '+';
       
       }
        if( k == 2 && i>1 && i<13){
       
          table[i][k] = '+';
       
       }
       
        if( k == 25 && i>3 && i<13){
       
          table[i][k] = '+';
       
       }
       
        if( k>4 && k<25 && i >4&& i<10){
       
          table[i][k] = ' ';
       
       }
       
       if(i == 13 && k>0 && k<29){
       
        table[i][k] = ' ';
        
       }
       
       
       if(i == 1 && k>0 && k<29){
       
        table[i][k] = ' ';
        
       }
       
        if( k==1 && i>0 && i<14){
       
        table[i][k] = ' ';
        
       }
       
       
        if( k==3 && i>2 && i<12){
       
        table[i][k] = ' ';
        
       }
       
        if( k==26 && i>2 && i<12){
       
        table[i][k] = ' ';
        
       }
       
       
       if( k==28 && i>0 && i<14){
       
        table[i][k] = ' ';
        
       }
       
       if( k==3 && i>2 && i<12){
       
        table[i][k] = ' ';
        
       }
       
       if( i == 3 && k>2 && k<27){
       
        table[i][k] = ' ';
        
       }
       
       if( i == 11 && k>2 && k<27){
       
        table[i][k] = ' ';
        
       }
       
    if((i == 1 && k== 14) || (i == 7 && k== 28) || (i == 13 && k== 14) || (i == 3 && k== 10) || (i == 3 && k== 18) || (i == 5 && k== 26) || (i == 10 && k== 26) || (i == 11 && k== 10) || (i == 11 && k== 18) ){
    
      table[i][k] = 'x';
    
    }
    
    if((i == 2 && k== 1) || (i == 4 && k== 3)  ){
    
      table[i][k] = '_';
    
    }
    
  
  
  }

  }
  
  
  
  //race start
  
  
  
    if(count1==13 || count1==33||  count1== 53){ //penalty situation handling
    
    printf("Penalty point for 1\n ");
      count1 = count1-2;
    
    }
  
  
     if(count1==77){
    
     count1 = count1+1;
    
    }
  
    if(count1 == 0){// 1 player
     
     
     
     table[1][1] = '1';
     
     
     
    } 
  
 
   
    if(count1 <= 27){// 1 player
     
     
     
     table[1][count1+1] = '1';
     
     
     
    } 
    
    
    
    if(count1 >27 &&  count1<40){// 1 player
     
     
     
     table[count1-26][28] = '1';
     
     
     
    } 
   
   
    if(count1 >= 40 &&  count1<67){// 1 player
     
     
     
     table[13][67-count1] = '1';
     
     
     
    } 
   
   
   
    if(count1 >= 67&& count1<79){// 1 player
     
     
     
     table[79-count1][1] = '1';
     
     
     
    } 
   
   
    if(count1>79){// 1 player
     
     if(count2<63){
       printf("Player 1 won");
     }
     
     table[1][1] = '1';
     
     
     
    } 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   if(count2 == 0){ // 2 player
    
     table[3][3] = '2';
    
    }
  
  
  
   if(count2==7 || count2==15||  count2== 25 ||  count2== 30 ||  count2== 39 ){
   
      
    printf("Penalty point for 2\n");
      count2 = count2-2;
    
    }
  
  
    if(count2==61){
    
     count2 = count2+1;
    
    }
  
    
  
 
   
    if(count2 <= 23){// 2 player
     
     
     
     table[3][count2+3] = '2';
     
     
     
    } 
    
    
    
    if(count2 >23 &&  count2<=31){// 2 player
     
     
     
     table[count2-20][26] = '2';
     
     
     
    } 
   
   
    if(count2 >31 &&  count2<55){// 2player
     
     
     
     table[11][57-count2] = '2';
     
     
     
    } 
   
   
   
    if(count2 >= 55 && count2<63){ // 2 player
     
     
     
     table[65-count2][3] = '2';
     
     
     
    } 
   
   
    if(count2>=63){ // 2 player
     
      if(count1<79){
       printf("Player 2 won\n");
     }
     
     table[3][3] = '2';
     
     
     
    } 
   
   
   
   
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  //race end
  
  
  
  
  
  
  
  
  
  //printing race
  
  

    for(int i = 0;i<15;i++){
  
     for(int k = 0;k<30 ; k++){
  
      
    if((i == 1 && k== 14) || (i == 7 && k== 28) || (i == 13 && k== 14) || (i == 3 && k== 10) || (i == 3 && k== 18) || (i == 5 && k== 26) || (i == 10 && k== 26) || (i == 11 && k== 10) || (i == 11 && k== 18) ){
    
      printf("\033[1;31m");
             
       printf("%c",table[i][k]);
       
            printf("\033[0m");
    
    }
    else{
    
    if( (i == 2 && k== 1) || (i == 4 && k== 3) ){
    
      printf("\033[0;32m");
             
       printf("%c",table[i][k]);
       
            printf("\033[0m");
     
    
    }
    else{
      if(table[i][k] == '1'){
      printf("\033[0;33m"); 
         printf("%c",table[i][k]);
          printf("\033[0m");
      }
      else{
      
      if(table[i][k] == '2'){
        printf("\033[0;34m");
         printf("%c",table[i][k]);
          printf("\033[0m");
      }
      else{
         printf("%c",table[i][k]);
      }
      }
     
    }
       
      
  
  }
  
  
  
  
  
  
  }
  
  
     
       printf("\n");
  
  
  
  
  
  
  }














}


int dice (){



 int diceNum;
 
 srand( (unsigned)time( NULL ) ) ;//for different randoms

 diceNum =  (rand() % 6)+ 1;
  











printf("Dice : %d \n" ,diceNum );

return diceNum;


}

int startGame (){

 char c ;
 int d1,d2,decision;
 printf("\033[0;33m"); 
 printf("Player 1 press enter to dice\n");
 printf("\033[0m");
 c = getchar();
 if(c = '\n'){
   d1 = dice();
   }
  else{
  
   while(c = '\n'){
   
    printf("\033[0;33m"); 
    printf("Player 1 press enter to dice\n");
    printf("\033[0m");
     c = getchar();
   
   
   }
   
      d1 = dice();
  
  
  } 
   
   printf("\033[0;34m");
   printf("Player 2 press enter to dice\n");
   printf("\033[0m");
   c = getchar();
   if(c = '\n'){
   d2 = dice();
   }
  else{
  
   while(c = '\n'){
   
    printf("\033[0;34m");
    printf("Player 2 press enter to dice\n");
    printf("\033[0m");
     c = getchar();
   
   
   }
   
      d2 = dice();
  
  
  } 
 
 if (d1 > d2){
 
 
 decision = 1;
 
   printf("***Player 1 will start the game***\n");
 

 
 
 }
 else{
 
 decision = 2;
  printf("***Player 2 will start the game***\n");
 
 }










 return decision;





}
