#include<stdio.h>
#include<math.h>
#define pi 3.14  


int select_shape ();
int select_calc ();
int calculate (int (*f)(), int (*p)());
int calc_triangle(int calc);
int calc_quadrilateral(int calc);
int calc_circle(int calc);
int calc_pyramid(int calc);
int calc_cylinder(int calc);
int numberTaking(); // I added this function because I do it so often 

enum shapes{Triangle = 1,Quadrilateral,Circle,Pyramid,Cylinder};

enum calculators{Area=1 ,Perimeter ,Volume};



int main(){

  int exitOrNot = 1;// I used this like a boolean
  
  while (exitOrNot==1){

  

  printf("\n\nWelcome to geometric calculator\n\n");
  
 
  exitOrNot = calculate ( select_shape , select_calc );
  
  


}





return 0;
}


int select_shape (){

 char shapeChoiceC,trash;
 int shapeChoice;



   printf("Select a shape to calculate:\n");
  printf("----------------------------\n");
  
  printf("1.Triangle\n2.Quadrilateral\n3.Circle\n4.Pyramid\n5.Cylinder\n0.Exit\n");

  printf("----------------------------\n");
  
  printf("Input: ");  

  scanf("%c",&shapeChoiceC);
  scanf("%c",&trash);
  
  shapeChoice = shapeChoiceC - '0';
  
  while (shapeChoice < 0 || shapeChoice>5){
  
  printf("You have entered invalid choice please enter your choice again");  
  
   printf("Input: ");  

   scanf("%c",&shapeChoiceC);
   scanf("%c",&trash);
  
   shapeChoice = shapeChoiceC - '0';
  
  
  } 


 
 return shapeChoice;


}


 int select_calc (){
 
 
 char calcChoiceC,trash;
  int calcChoice;
 
 
   
   printf("Select calculator:\n");
  printf("----------------------------\n");
  
  printf("1.Area\n2.Perimeter\n3.Volume\n0.Exit\n");

  printf("----------------------------\n");
  
  printf("Input: ");  
 
 
  scanf("%c",&calcChoiceC);
  scanf("%c",&trash);
  
  
  
  calcChoice = calcChoiceC - '0';
  

  while (calcChoice < 0 || calcChoice>3){
  
  printf("You have entered invalid choice please enter your choice again\n");  
  
   printf("Input: ");  
  
  
   scanf("%c",&calcChoiceC);
    scanf("%c",&trash);
    
   calcChoice = calcChoiceC - '0';
  
  
  } 
 
 
 
 

 
 
 
 return calcChoice;
 }
 
 
 int calculate (int (*f)(), int (*p)()){
 
 
 int shape,calc,answer,exitOrNot;
 
 
  shape = f();
  
  if(shape != 0)
   calc = p();
 

 
 
 
  switch( shape ){
  
     case 0 : 
     
     
     
     break;
   
    
    case Triangle :
    
       while(calc == Volume )
       {
       
         printf("\nyou cannot calculate volume of Triangle. Please try again\n");
         calc = p();
         
       
       } 
       if(calc != 0) 
       answer = calc_triangle(calc);  
       
       if ( calc == Area) {
        
        printf("\nArea of Triangle is : %d \n",answer);
       
       
       }
       if(calc == Perimeter){
       
        printf("\nPerimeter of Triangle is : %d \n",answer);
       
       
       }   
    
    
    break;
    
    case Quadrilateral : 
    
    
      
       while(calc == Volume )
       {
       
         printf("\nyou cannot calculate volume of Quadrilateral. Please try again\n");
         calc = p();
         
       
       } 
       if(calc != 0) 
       answer = calc_quadrilateral(calc);  
       
       if ( calc == Area) {
        
        printf("\nArea of Quadrilateral is : %d \n",answer);
       
       
       }
       if(calc == Perimeter){
       
        printf("\nPerimeter of Quadrilateral is : %d \n",answer);
       
       
       }   
    
    
    
    break;
    
    
      case Circle : 
    
    
       while(calc == Volume )
       {
       
         printf("\nyou cannot calculate volume of Circle. Please try again\n");
         calc = p();
         
       
       } 
       if(calc != 0) 
        answer = calc_circle(calc);  
       
       if ( calc == Area) {
        
        printf("\nArea of Circle is : %d \n",answer);
       
       
       }
       if(calc == Perimeter){
       
        printf("\nPerimeter of Circle is : %d \n",answer);
       
       
       }   
    
    
    
    break;  
    
  
    
      case Pyramid : 
    
      
      
      while(calc == Perimeter)
       {
       
         printf("\nyou cannot calculate perimeter of Pyramid. Please try again\n");
         calc = p();
         
       
       } 
       
       if(calc != 0) 
         answer = calc_pyramid(calc);
       
       if ( calc == Area) {
        
        printf("\nArea of Pyramid is : %d \n",answer);
       
       
       }
      
        if(calc == Volume){
       
        printf("\nVolume of Pyramid is : %d \n",answer);
       
       
       }   
    
    
    break;  
    
    
      case Cylinder : 
      
       while(calc == Perimeter)
       {
       
         printf("\nyou cannot calculate perimeter of Cylinder. Please try again\n");
         calc = p();
         
       
       }  
      if(calc != 0) 
       answer = calc_cylinder(calc);  
       
       
       if ( calc == Area) {
        
        printf("\nArea of Cylinder is : %d \n",answer);
       
       
       }
      
        if(calc == Volume){
       
        printf("\nVolume of Cylinder is : %d \n",answer);
       
       
       }   
    
    
    
    
    
    break;  
    
  
  
  
  
  
  
  
  }



   if (shape == 0 || calc == 0){
   
  exitOrNot = 0;
  }
  else{
   
   exitOrNot=1;
  
  }
 
 
 
 
  return exitOrNot;
 
 }
 
 
 
 
 
 
 
 
 int calc_triangle(int calc){
 
  int s1,s2,s3;
  int answer;
  
  printf("\nPlease enter 3 sides of triangle\n");
  
   s1 = numberTaking();
  
   while(s1 == 0 ){
    
     s1 = numberTaking();
   
   }
   
      s2 = numberTaking();
  
   while(s2 == 0 ){
    
     s2 = numberTaking();
   
   }
 
   
 
    s3 = numberTaking();
  
   while(s3 == 0 ){
    
     s3 = numberTaking();
   
   }
 
 
 
   while (s2+s1 <s3 || s1 + s3 < s2 || s2 + s3 < s1 ){
    
    printf("Please enter valid triangle\n");
    
    printf("Please enter 3 sides of triangle\n");
  
   s1 = numberTaking();
  
   while(s1 == 0 ){
    
     s1 = numberTaking();
   
   }
    
    
      s2 = numberTaking();
  
   while(s2 == 0 ){
    
     s2 = numberTaking();
   
   }
   
   
 
 
     
    s3 = numberTaking();
  
   while(s3 == 0 ){
    
     s3 = numberTaking();
   
   }
 
    
   
   
   }
   
   
   if ( calc == Area){
   
   
   int s = (s1+s2+s3)/2;
   int areasquare = s*(s-s1) * (s-s2) * (s-s3); 
   int area = sqrt(areasquare);
   answer = area;
   
   
   
   
   
   
   
   
   
   }
   if(calc == Perimeter){
   
   
    
   
   answer = s1+s2+s3;
   
   
   }
 
 
 
 
 
 
 
 
 
 
 
 
  return answer;
 
 }
 
 
 int numberTaking(){
 
  int boo = 1;
  int a;
 char ac = ' ';
 
 


  int count  = 0 ;
  int sum ;
  
  while (ac != '\n' && boo == 1){
  
  
   scanf("%c",&ac);
  
   
    if(ac != '\n'){
     a = ac - '0';
     
   
     if (a<10 && a>-1){
  
    if (count == 0 ) {
    
    sum = a;
    
   
     count++;
    
    }
    else{
    
    
    sum = sum*10 + a;
    
    
    
    
    }
  
  
  
  }
  else{
  
  
   printf("invalid value\n");
   sum = 0;
   boo = 0;
  
  }
   
   
   
   }
  
  

  
  
  
  }





  
  
    
 
    return sum;
 
 
 }
 
 
 
 int calc_quadrilateral(int calc){
 
   int s1,s2,s3,s4;
 
  int answer;
  
  printf("Please enter 4 sides of quadrilateral\n");
  
   s1 = numberTaking();
  
   while(s1 == 0 ){
    
     s1 = numberTaking();
      
   
   } 
   
  
 
      s2 = numberTaking();
      
  
   while(s2 == 0 ){
    
     s2 = numberTaking();
   
   }
  
   
 
 
 
    s3 = numberTaking();
  
   while(s3 == 0 ){
    
     s3 = numberTaking();
   
   }
 
 
 
   
    s4 = numberTaking();
  
   while(s4 == 0 ){
    
     s4 = numberTaking();
   
   }
  
 
 
 
   
   
   if ( calc == Area){
   
   
   int s = (s1+s2+s3+s4)/2;
   int areasquare = (s-s4)*(s-s1) * (s-s2) * (s-s3); 
   int area = sqrt(areasquare);
   answer = area;
   
   
   
   
   
   
   
   
   
   }
   if(calc == Perimeter){
   
   
    
   
   answer = s1+s2+s3+s4;
   
   
   }
 
 

 
 
 
 
 return answer;
 }
 
 
 int calc_circle(int calc){
 
 
 int r ;
 
  int answer;
  
  printf("Please enter radius of Circle\n");
  
   r = numberTaking();
  
   while(r == 0 ){
    
     r = numberTaking();
   
   }
 
 
    if ( calc == Area){
   
   

   int area = pi * r*r;
   answer = area;
   
   
   
   
   
   
   
   
   
   }
   if(calc == Perimeter){
   
   
    
   
   answer = 2*pi*r;
   
   
   }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  return answer;
 
 
 
 
 
 
 
 }
 
 
 int calc_pyramid(int calc){
 
 
  int base,height,answer;
  
  printf("Please enter the base side and height of a Pyramid:\n");
  
  base = numberTaking();
  
   while(base == 0 ){
    
     base = numberTaking();
   
   }
 
  height = numberTaking();
  
   while(height == 0 ){
    
     height = numberTaking();
   
   }
 
 
 
    if ( calc == Area) {
        
        int baseArea = base*base;
        int lateralHeight = sqrt((base/2)*(base/2) + height*height);
        int lateralArea = base*lateralHeight*2;
        answer = lateralArea + baseArea;
        printf("Base area of Pyramid is : %d \n",baseArea);
        printf("Lateral area of Pyramid is : %d \n", lateralArea);
       
       
       }
     
        if(calc == Volume){
       
        answer = base*base*height/3 ;
       
       
       } 
 
 
 
 
 
 
 
 
 return answer;
 
 
 
 }
 
 int calc_cylinder(int calc){
 
 
 
  int r,height,answer;
  
  printf("Please enter the radius and height of a Cylinder:\n");
  
  r= numberTaking();
  
   while(r == 0 ){
    
     r = numberTaking();
   
   }
 
  height = numberTaking();
  
   while(height == 0 ){
    
     height = numberTaking();
   
   }
 
 
 
    if ( calc == Area) {
        
        int baseArea = pi*r*r;
        int lateralArea = 2*pi*r*height;
        answer = 2*pi*r*(r+height);
        printf("Base area of Cylinder is : %d \n",baseArea);
        printf("Lateral area of Cylinder is : %d \n", lateralArea);
       
       
       }
     
        if(calc == Volume){
       
        answer = pi*r*r*height ;
       
       
       } 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 return answer;
 }
