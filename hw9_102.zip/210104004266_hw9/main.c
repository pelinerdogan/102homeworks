#include<stdio.h>
#include<stdlib.h>
#include<string.h>
union Person{

 char name[50];
 
 char address[50];
 
 int phone;
 };
 
 
union Loan{

 float amount;
 
 float interestRate;
 
 int period;
 };
 
 
struct  BankAccount{

 union Person customer;
 union Loan loans[3] ;
 };
 float powmine(float rate,int period);
void listCustomers(struct BankAccount *bank,int customercount);
struct BankAccount addCustomer (int customerCount);
void newLoan (struct BankAccount *bank,int *customerLoanNum,int customercount);
float calculateLoan(float amount, int period, float interestRate);
void getReport();
 
 
 
 
 
 
int main(){

int *loanc ;

loanc = (int *) calloc(50,sizeof(int));


int exit = 0;
struct BankAccount bank[50];
int customerCount = 0;
do{
 
 printf("\nWelcome to Bank managment System\n------------------------\n");

 printf("1. List all customers\n2. Add new customer\n3. New loan application\n4. Report menu\n5. exit system\n");
 
 int choice;
 
 scanf("%d",&choice);
 
 switch(choice){
 
 
  case 1:
  
  listCustomers(bank, customerCount);
   break;
 
 
  case 2:
  if(customerCount<50){
  bank[customerCount] = addCustomer (customerCount);
  
  
  customerCount++;
  }else{
  
   printf("you can't create more customers");
  }
  
  
   break;
   
  
  case 3:
  
     newLoan (bank,loanc,customerCount);
  
   break;
   
  
  case 4:
  
    getReport();
  
   break;
   
  
  case 5:
  
    exit =1;
   break;   
 
 
 
 
  
 
 
 
 
 
 }




}while(exit!=1);



return 0;
}






float calculateLoan(float amount, int period, float interestRate){

 
 float loancalc = amount*powmine(interestRate/100+1,period);




 return loancalc;



}


float powmine(float rate,int period){
 float end ;  

  if(period!=1){
   
   
   end= rate*powmine(rate,period-1);
   return end;
     
 
 
 }
 
 







}


void listCustomers(struct BankAccount *bank,int customercount){


  for(int i = 0;i<customercount;i++){
  
  
  printf("Customer Name: %s\n" , bank[i].customer.name);
  printf("loans %.2f + %.2f + %.2f = %.2f\n", bank[i].loans[0].amount,bank[i].loans[1].amount,bank[i].loans[2].amount,bank[i].loans[0].amount+bank[i].loans[1].amount+bank[i].loans[2].amount);
  
  
  
  
  }



}


struct BankAccount addCustomer (int customerCount){
 char trash;
 
 
 struct BankAccount newacc;
 FILE *ptr;
 
 
 ptr = fopen("customer.txt","a");
 
 char namescan[50];
 int id =customerCount +1;
 
 
 
 fprintf(ptr,"Customer ID: %d \n",id);
 
 printf("please enter customer name:");
 scanf("%c",&trash);
 fflush(stdin);
 scanf("%[^\n]%*c",newacc.customer.name);
 fprintf(ptr,"Customer Name: %s \n",newacc.customer.name);
 
 strcpy(namescan,newacc.customer.name);
 
 printf("please enter customer address:");
 
 fflush(stdin);
 scanf("%[^\n]%*c",newacc.customer.address);
 fprintf(ptr,"Customer address: %s \n",newacc.customer.address);
 
 fflush(stdin);
 
 printf("please enter customer phone:");
 
 scanf("%d",&newacc.customer.phone); 
 fprintf(ptr,"Customer phone: %d \n\n",newacc.customer.phone); 

 fclose(ptr);
 
 
 strcpy(newacc.customer.name,namescan);

 newacc.loans[0].amount = 0;
 newacc.loans[1].amount = 0;
 newacc.loans[2].amount = 0;

 
 
 return newacc;

}


void newLoan (struct BankAccount *bank,int *customerLoanNum,int customercount){
 
 int id;
 int p;
 float a,r;
 FILE *ptr;
 ptr = fopen("loans.txt","a+");
 
 printf("\nplease enter customer ID of the customer:");
 
 scanf("%d",&id);
 
 int exit = 0;
 
 while(id>customercount && exit!= 1 ){
 
  printf("\ncustomer not found try again or enter -1 to exit :");
 
  scanf("%d",&id);
  if(id== -1)
  exit = 1;
 
 
 }
 if(exit == 0){
 if(customerLoanNum[id-1]<3){
 
 fprintf(ptr,"\n Customer ID: %d ",id);
 fprintf(ptr,"\nCustomer name: %s ",bank[id-1].customer.name);
 
 
 printf("\nplease enter amount you want:");
 scanf("%f",&bank[id-1].loans[customerLoanNum[id-1]].amount);
 fprintf(ptr,"\namount : %.2f " ,bank[id-1].loans[customerLoanNum[id-1]].amount);
 a = bank[id-1].loans[customerLoanNum[id-1]].amount;

 
 printf("\nplease enter interest rate you want:");
 scanf("%f",&bank[id-1].loans[customerLoanNum[id-1]].interestRate);
 fprintf(ptr,"\ninterest rate : %.2f " ,bank[id-1].loans[customerLoanNum[id-1]].interestRate);
 r = bank[id-1].loans[customerLoanNum[id-1]].interestRate;
 
 printf("\nplease enter period you want:");
 scanf("%d",&bank[id-1].loans[customerLoanNum[id-1]].period);
 fprintf(ptr,"\nperiod %d " ,bank[id-1].loans[customerLoanNum[id-1]].period);
 p =bank[id-1].loans[customerLoanNum[id-1]].period;
 
 
 
 bank[id-1].loans[customerLoanNum[id-1]].amount = calculateLoan(a, p, r);
 
 float monthly = bank[id-1].loans[customerLoanNum[id-1]].amount/p;
    fprintf(ptr,"\ntotal %.2f" ,bank[id-1].loans[customerLoanNum[id-1]].amount);  
 for(int i = 1; i<=p;i++){
  
   fprintf(ptr,"\n%d month %.2f " ,i ,monthly);
 
 } 
 customerLoanNum[id-1]++;
 
 
 }
 else{
  
   printf("\nthis user cant have more loans\n");
   
 
 }
 
 
 
 
 }
 
 
 
 
 
 
 
 
 
 

 
 fclose(ptr);
  

   






}


void getReport(){
   int choice;
   printf("sub menu:\n1. customer details\n2. loan details\n");
   scanf("%d",&choice);
   while(choice >2 && choice < 1){
   
   printf("sub menu:\n1. customer details\n2. loan details\n");
   scanf("%d",&choice);
   
   
   }
   
   if(choice==1){
   
   
   


 FILE *ptr;
 
 
 ptr = fopen("customer.txt","r");
 
 while(!feof(ptr)){
 
  char c ;
  
  fscanf(ptr,"%c",&c);
  
  printf("%c",c);
 
 
 }





fclose(ptr);


}




  
 if(choice==2){
   
   
   


 FILE *ptr2;
 
 
 ptr2 = fopen("loans.txt","r");
 
 while(!feof(ptr2)){
 
  char c ;
  
  fscanf(ptr2,"%c",&c);
  
  printf("%c",c);
 
 
 }





fclose(ptr2);


}












}
