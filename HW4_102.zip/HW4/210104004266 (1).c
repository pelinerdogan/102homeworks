#include<stdio.h>

void graph();
void write();
void graphf();


int main(){



  int choice;


  

   do{
   
    
  printf("Select an operation...\n1 -> Enter the coefficients\n2 -> Draw the graph\n3 -> Print the graph into a .txt file.\n4 -> Exit\n");
  scanf("%d",&choice);
  printf("choice : %d \n",choice);
 
  while( choice < 0 || choice>4){
  
  
  
  
  printf("You have entered an invalid choice\n");
  printf("Select an operation...\n 1 -> Enter the coefficients\n2 -> Draw the graph\n3 -> Print the graph into a .txt file.\n4 -> Exit\n");
  scanf("%d",&choice);
  printf("choice : %d \n",choice);
 
  }
  
    
  
    if(choice == 1){
    
   
     write();
     
 
    
    }
    
    if(choice == 2){
    
    graph();
    
    }
  
    if(choice == 3){
      graphf();
      
    }
  
  
  
  
  
  
  
  
  
  
 
   
  
  }  while(choice !=4);

     
  printf("exiting...\n");




















return 0;

}


void graph(){


  FILE *input;
  
 input= fopen("coefficients.txt" , "r+");
  
  int a,b,c;
  a=0;
  b=2;
  c=1;
  
  fscanf(input,"%d",&a);
  fscanf(input,"%d",&b);
  fscanf(input,"%d",&c);
  
  ;
  int x;
  int y; 


   for( y = 15 ; y>0; y--){ //upper part
      
      x = a*(y*y) + b*y + c;
    
        
   
     
     
      if(x<=0 && x>-56){ // 1 area
      
      int r = 0;
      
      if(a==0&&b==0)
      r = 1;
      
      for(int i = 56- x*(-1) -r ; i>0 ;i--){
      
            printf(" ");
            
          
        
        }
        
        
          
        
           if(x!=0){
           printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
             }
         
         for(int l=(x*(-1)) -1 ; l>0 ;l--){
            printf(" ");
                
        
         }
                    
          if(x!=0){
          printf("|");
          }
          else{
          printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
          }
          
            if(y%5==0){
            if (x!=y){
            printf("\033[1;31m");
              printf("%d",y);
            printf("\033[0m");
            }
               if(y==5){
              x=x-1;
             }
             else{
             x=x-2;
             }
          }
      }
     
      
        
      
      
      
      if(x>0 && x<56){ // second area
      
        for(int l = 56 ; l>0 ;l--){
            printf(" ");
            
          
        }
        
            printf("|");
          
          if(y%5==0 && y!=0 && (c>3 || c<-3) ){
          
          
            printf("\033[1;31m");
              printf("%d",y);
            printf("\033[0m");
              
             if(y==5){
             
                x=x-1;
             }
             else{
             x=x-2;
             }
             
          }
      
     
      
         for(int i = x-1; i>0 ;i--){
            printf(" ");
         }
         
         printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
      
      }
    
       printf("\n");
    }
       
    
      
    
       for(int k=-55; k<0; k++){
      
        
        if(k!=x){
          printf("-");
            }
        if(k==x && x!=0){
        printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
          
          }
          
       
       }
       
       
        for(int k=0; k<56; k++){
        
        if(k!=x){
          printf("-");
            }
        if(k==x && x!=0){
        
            if (b==0)
            printf("-");
          printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
          
         } 
       
       
       }
    
      printf("\n");
     
    
      for( y = 0 ; y>-16; y--){//down part
      
      x = a*(y*y) + b*y + c;
    
        
   
     
     
      if(x<=0 && x>-56){// third area
      
      for(int i = 55- x*(-1) ; i>0 ;i--){
      
            printf(" ");
          
        
        }
        
        
          
        
           if(x!=0)  { 
           printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
         }
         for(int l=(x*(-1))  ; l>0 ;l--){
            printf(" ");
                
        
         }
                    
          if(x!=0){
          printf("|");
          }
          else{
          printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
          }
          
            if(y%5==0 && (c>3 || c<-3)){ //to not write numbers when they collaps 
              printf("\033[1;31m");
              printf("%d",y);
            printf("\033[0m");
             
               if(y==-5){
              x=x-2;
             }
             else{
             if(y!=0)
             x=x-3;
             }
          }
      }
     
      
        
      
      
      
      if(x>0 && x<56){ // fourth area
      
        for(int l = 56 ; l>0 ;l--){
            printf(" ");
          
        }
        
            printf("|");
              if(y%5==0 && (c>3 || c<-3)){
            printf("\033[1;31m");
              printf("%d",y);
            printf("\033[0m");
               if(y==-5){
              x=x-2;
             }
             else{
             if(y==0){
               x=x-1;
             }
             else{
             x=x-3;
             }
             }
          }
          
          
          
      
         int d =1;
         if(a==0 && b!=0 && c!=0)
         d = 2;
      
      
         for(int i = x-d; i>0 ;i--){

            printf(" ");
         }
             printf("\033[0;34m");
             printf("#");
             printf("\033[0m");
      
      }
    
       printf("\n");
    }









   fclose(input);

}


void write(){


  int a,b,c;
  a=1;
  b=2;
  c=3;
  
    FILE *output ;
      
    output= fopen("coefficients.txt" , "w+");
        
     
    printf("Please enter the coefficient for the following equation : x = a*(y*y) + b*y + c\n");
     
     printf("a : ");

     scanf("%d" , &a);
    
     printf("b : ");

     scanf("%d" , &b);
     
     printf("c : ");

     scanf("%d" , &c);
     
     
     fprintf(output , "%d " , a);
     fprintf(output , "%d " , b);
     fprintf(output , "%d " , c);



  




    fclose(output);

    






}





















void graphf(){


  FILE *input;
  
 input= fopen("coefficients.txt" , "r+");
  
  FILE *output;
  
 output= fopen("graph.txt" , "w"); 
  int a,b,c;
  a=0;
  b=2;
  c=1;
  
  fscanf(input,"%d",&a);
  fscanf(input,"%d",&b);
  fscanf(input,"%d",&c);
  
  ;
  int x;
  int hit;
  int y; 


   for( y = 15 ; y>0; y--){
      
      x = a*(y*y) + b*y + c;
    
        
   
     
     
      if(x<=0 && x>-56){
      
      int r = 0;
      
      if(a==0&&b==0)
      r = 1;
      
      for(int i = 56- x*(-1) -r ; i>0 ;i--){
      
            fprintf(output," ");
            
          
        
        }
        
        
          
        
           if(x!=0){
           
             fprintf(output,"#");
             
             }
         
         for(int l=(x*(-1)) -1 ; l>0 ;l--){
            fprintf(output," ");
                
        
         }
                    
          if(x!=0){
          fprintf(output,"|");
          }
          else{
         
             fprintf(output,"#");
            
          }
          
           
      }
     
      
        
      
      
      
      if(x>0 && x<56){
      
        for(int l = 56 ; l>0 ;l--){
            fprintf(output," ");
            
          
        }
        
            fprintf(output,"|");
          
         
     
      
         for(int i = x-1; i>0 ;i--){
            fprintf(output," ");
         }
         
         
             fprintf(output,"#");
             
      
      }
    
       fprintf(output,"\n");
    }
       
    
      
    
       for(int k=-55; k<0; k++){
      
        
        if(k!=x){
          fprintf(output,"-");
            }
        if(k==x && x!=0){
       
             fprintf(output,"#");
            
          
          }
          
       
       }
       
       
        for(int k=0; k<56; k++){
        
        if(k!=x){
          fprintf(output,"-");
            }
        if(k==x && x!=0){
        
            if (b==0)
           fprintf(output,"-");
          
             fprintf(output,"#");
            
          
         } 
       
       
       }
    
      fprintf(output,"\n");
     
    
      for( y = 0 ; y>-16; y--){
      
      x = a*(y*y) + b*y + c;
    
        
   
     
     
      if(x<=0 && x>-56){
      
      for(int i = 55- x*(-1) ; i>0 ;i--){
      
            fprintf(output," ");
          
        
        }
        
        
          
        
           if(x!=0)  { 
           
             fprintf(output,"#");
             
         }
         for(int l=(x*(-1))  ; l>0 ;l--){
            fprintf(output," ");
                
        
         }
                    
          if(x!=0){
          fprintf(output,"|");
          }
          else{
          
             fprintf(output, "#");
            
          }
          
            
      }
     
      
        
      
      
      
      if(x>0 && x<56){
      
        for(int l = 56 ; l>0 ;l--){
            fprintf(output," ");
          
        }
        
            fprintf(output,"|");
             
          
          
          
      
         int d =1;
         if(a==0 && b!=0 && c!=0)
         d = 2;
      
      
         for(int i = x-d; i>0 ;i--){

            fprintf(output," ");
         }
        
             fprintf(output,"#");
             
      
      }
    
       fprintf(output,"\n");
    }









   fclose(input);
   fclose(output);
   
      printf("the graph of x = %d(y*y)+%dy+%d is written on graph.txt" ,a,b,c);


}
