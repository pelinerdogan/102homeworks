#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {


    int choice;
    printf("Please select which problem you like to solve. \n Options : 1 , 2 or 3 \n");
    scanf("%d" ,&choice );
    
    switch(choice){
    
      case 1 : {
      
      float pl,pw,sw,sl;
      
        printf("Please enter pl real number:\n");
        scanf("%f",&pl);
        
        printf("Please enter pw real number:\n");
        scanf("%f",&pw);
        
        printf("Please enter sw real number:\n");
        scanf("%f",&sw);
        
        printf("Please enter sl real number:\n");
        scanf("%f",&sl);
        
         char resultA = dt1a(pl, pw , sw , sl);
         char resultB = dt1b(pl, pw , sw , sl);
          
           switch(resultA){
            case 'v':
              printf("Result : versicolor");
            break;
            
            case 's':
              printf("Result : setosa");
            break;
            
            case 'g':
              printf("Result : virginica");
            break;
           
           }
           
           if (resultA != resultB){
           
              switch(resultB){
            case 'v':
              printf("and versicolor\n");
            break;
            
            case 's':
              printf(" and setosa\n");
            break;
            
            case 'g':
              printf(" and virginica\n");
            break;
           
           }
           
           
           }
           
           printf("\n");
        break;
        }
      case 2 :{
        double x1,x2,x3; 
        int x5,x4;
        
        printf("Please enter x1 real number:\n");
        scanf("%lf",&x1);
        
        printf("Please enter x2 real number:\n");
        scanf("%lf",&x2);
        
        printf("Please enter x3 real number:\n");
        scanf("%lf",&x3);
        
        
        printf("Please enter x4 (1 or 0):\n");
        scanf("%d",&x4);
           while(x4<0 || x4>1){
           printf("Please enter a valid value:");
           scanf("%d" , &x4); 
         }
        
        printf("Please enter x5 (1 or 0):\n");
        scanf("%d",&x5);
           while(x5<0 || x5>1){
           printf("Please enter a valid value:");
           scanf("%d" , &x5); 
         }
         
         double aTree = dt2a( x1 , x2 , x3,  x4 , x5);
         double bTree = dt2b( x1 , x2 , x3,  x4 , x5); 
         
         if((aTree - bTree == CLOSE_ENOUGH )|| (bTree - aTree == CLOSE_ENOUGH )){
          
          printf("Result %.2f\n" , (aTree + bTree)/2);
           
         }
          if(aTree == bTree){
          
          printf("Result %.2f\n" , aTree );
           
         }
         else{
           printf("Result %.2f and %.2f\n"  , aTree ,bTree );
       
         }
         
         
        break;
        }
      case 3 :{
      
         int pain_complain,no_pain_complain,pain,film;
         double brush_per_day,age;
         printf("This program is build for dentistry. \nProgram will say which department you should go \n");
        printf("\nPlease enter your age (example : if you are 40 year old 6 month enter 40.5\n if you are 20 year 3 month enter 20.25):");
        scanf("%lf" , &age);
        
          while(age<1){
           printf("\nPlease enter a valid age value:");
           scanf("%lf" , &age);
          }
        
        printf("\nHow many times do you brush your teeth in a day?(if you brush once in two days enter 0.5 \n if you brush once in 3 days enter 0.33:");
        scanf("%lf" , &brush_per_day); 
         
          while(brush_per_day<0){
           printf("\nPlease enter a valid value:");
           scanf("%lf" , &brush_per_day); 
        }
        
        printf("\nDo you have a radiography (press 1 for yes 0 for no):");
        scanf("%d" , &film);
           
           while(film<0 || film>1){
           printf("\nPlease enter a valid value:");
           scanf("%d" , &film); 
        }
        
         printf("\nDo you have pain (press 1 for yes 0 for no):");
        scanf("%d" , &pain);
           
           while(pain<0 || pain>1){
           printf("\nPlease enter a valid value:");
           scanf("%d" , &pain); 
         }
         
         printf("\n\nPlease make your decision between painless complaints\n1-Bleeding gum\n2-Jaw locking\n3-Tartar\n4-Crooked teeth\n5-Missing teeth\n6- I have no painless complaint\n"); 
         scanf("%d" , &no_pain_complain);
          while(no_pain_complain<0 || no_pain_complain>6){
           printf("Please enter a valid value:");
           scanf("%d" , &no_pain_complain);  
           
          } 
          
          printf("\n\nPlease make your decision between painfull complaints\n1-Dental absecess\n2-Jaw fracture\n3-Tooth pain with no color on teeth\n4-Tooth pain with color on teeth\n5-Major teeth fraction\n6- I have no painfull complaint\n\n"); 
          scanf("%d" , &pain_complain);
          while(pain_complain<0 || pain_complain>6){
           printf("\nPlease enter a valid value:");
           scanf("%d" , &pain_complain);  
           
          }
          
        int treeA =dt3a(age ,  brush_per_day,  pain ,  film , pain_complain , no_pain_complain);    
        int treeB =dt3b(age ,  brush_per_day,  pain ,  film , pain_complain , no_pain_complain); 
        
        if (treeB !=0){
        switch(treeA){
        
        case 0 :
           printf("There is an error. Try again\n");
         break;
        
        case 1 :
        
             printf("You should visit prosthesis\n");
        
         break;
        
        case 2 :
             printf("You should visit endodontia\n");
         break;
         
        case 3 :
             printf("You should visit pedodontia\n");
         break;
        
        case 4 :
             printf("You should visit periodontia\n");
         break;
         
        case 5 :
             printf("You should visit surgery\n");
         break;    
        
        case 6 :
             printf("You should visit radiology\n");
         break;
         
        case 7 :
             printf("You should visit orthodontia\n");
         break;
         
        case 8 :
             printf("You should visit restorative\n"); 
         break;
         
        case 9 :
             printf("You should visit restorative and peridontia\n");
         break;
         
        case 10 :
             printf("You should visit endodontia and periodontia\n");
         break;
         
        case 11 :
             printf("You should visit orthodontia and periodontia\n");
         break;
         
        case 12 :
             printf("You should visit surgery and periodontia\n");
         break;
         
        case 13 :
             printf("You should visit radiology and periodontia\n");
         break;
         
        case 14 :
             printf("You should visit prosthesis and periodontia for\n");
         break;
         
         
        }
       }  
        if (treeB != treeA && treeA != 0){
        switch(treeB){
        
        case 0 :
           printf("There is an error. Try again\n");
         break;
        
        case 1 :
        
             printf("You should visit prosthesis\n");
        
         break;
        
        case 2 :
             printf("You should visit endodontia\n");
         break;
         
        case 3 :
             printf("You should visit pedodontia\n");
         break;
        
        case 4 :
             printf("You should visit periodontia\n");
         break;
         
        case 5 :
             printf("You should visit surgery\n");
         break;    
        
        case 6 :
             printf("You should visit radiology\n");
         break;
         
        case 7 :
             printf("You should visit orthodontia\n");
         break;
         
        case 8 :
             printf("You should visit restorative\n"); 
         break;
         
        case 9 :
             printf("You should visit restorative and peridontia\n");
         break;
         
        case 10 :
             printf("You should visit endodontia and periodontia\n");
         break;
         
        case 11 :
             printf("You should visit orthodontia and periodontia\n");
         break;
         
        case 12 :
             printf("You should visit surgery and periodontia for\n");
         break;
         
        case 13 :
             printf("You should visit radiology and periodontia\n");
         break;
         
        case 14 :
             printf("You should visit prosthesis and periodontia \n");
         break;
         
      
      }
     }
     }
       break;
       default :
     
       printf("You have entered an invalid value");
    }
    /* Get the input from the user for the first problem, i.e., to test dt1a and dt1b */
    
    
    
    /* Compare performances and print results */

    /* Get the input from the user for the second problem, i.e., to test dt2a and dt2b */
    /* Compare performances and print results */

    /* Get the input from the user for the third problem, i.e., to test dt3a and dt3b */
    /* Compare performances and print results */

    return 0;
}
