#include <stdio.h>
#include <math.h>
#include "util.h"

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, char s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
}

char dt1a( float pl, float pw , float sw , float sl ){
 
 char char_for_return;
   
   if(pl<2.45){
     
    char_for_return = 's'; //setosa starts with s
   
   }
   else{
     
     if ( pw<1.75){
     
      if(pl < 4.95){
         
         if(pw<1.65){
           char_for_return = 'v';//versicolor has v in it
         }
         else{
           char_for_return = 'g';//virginica has g in it
         }
      }
      else{
        char_for_return = 'g';//virginica has g in it
      }
     
     }
     else{
       char_for_return = 'g';//virginica has g in it
     }
    
   
   }
  


 return char_for_return;
}



char dt1b( float pl, float pw , float sw , float sl ){
 
 
 char char_for_return;
   
   if(pl<2.55){
     
    char_for_return = 's'; //setosa starts with s
   
   }
   else{
     
     if ( pw<1.69){
     
      if(pl < 4.85){
         
         
           char_for_return = 'v';//versicolor has v in it
        
      }
      else{
        char_for_return = 'g';//virginica has g in it
      }
     
     }
     else{
       char_for_return = 'g';//virginica has g in it
     }
    
   
   }
  


 return char_for_return;
}


double dt2a(double x1 , double x2 ,double x3, int x4 , int x5){

 double value_for_return;

  if (x1<31.5){
     
     if(-2.5<x2){
    
     value_for_return = 5.0;
      
     }
     else{
      
         if( x2-0.1 <=x1 && x1<= x2+0.1){
    
         value_for_return = 2.1;
      
         }
       else{
    
         
         value_for_return = -1.1;
     

        }
       
    }
   
  
  
  }
  else{
    
    if(-1<x3 && x3<=2){
    
      value_for_return = 1.4;
      
    }
    else{
    
       if ((x4 & x5) == 1){
         value_for_return = -2.23;
       }
       else{
         value_for_return = 11.0;
       }
     
     
    }
  
  }






 
 return value_for_return;
}


double dt2b(double x1 , double x2 ,double x3, int x4 , int x5){

 double value_for_return;

   if (x1<22 && x1<12){
     
     if(5/3<x3){
    
     value_for_return = -2.0;
      
     }
     else{
      
         if( x1-0.1 <=x3 && x3<= x1+0.1){
    
         value_for_return = 1.01;
      
         }
       else{
    
         
         value_for_return = -8;
     

        }
       
    }
   
  
  
  }
  else{
    
   
    
       if((x4 & x5) == 1){ 
      
         value_for_return = -1; 
       
       }
       else{
       
         if(-1<= x2 && x2<=2){
          value_for_return = -1/7;
         }
         else{
           
           value_for_return = sqrt(2)/3;
         
         }
       
       }
     
     
    }
  
 


 
 return value_for_return;

}

int dt3a(double age , double brush_per_day, int pain , int film , int pain_complain , int no_pain_complain){


 int decision;

  if ( brush_per_day < 1 ){
   
    if(pain == 1){
      if (age<16){
        decision = 3;
      }
      else{ // older than 15
         decision = 6;
      }
    }
    else{ // no pain
         if (age<16){
        decision = 3;
      }
      else{
         decision = 4;
      }
    } 
  }
  
  
  else{ // brush more than 0
   
    if(pain == 1){
      
      if (pain_complain<4){
        
        if (film ==1){
           if (2<pain_complain && pain_complain<4){
             decision = 2;
           }
           else{
              if ( 1<pain_complain){
                decision = 5;
              }
              else{ // pain_complain = 1
                decision = 2;
              }
           }
        }
        else{ // no film
          decision = 6;
        }
        
      }
      else{ // pain_complain >4
        if ( 4<pain_complain && pain_complain<6){
          decision = 1;
        }
        else{// pain_complain not 4<pain_complain<6
          decision = 8;
        }
      }
   }
   else{ // no pain
      if (1<no_pain_complain && no_pain_complain<3){
        if(film == 1){
          decision = 5; 
        }
        else{//no film
          decision = 6;
        }
      }
      else{// not 1 <no pain_complain <3
        if(no_pain_complain < 2){
            decision = 4;
        }
        else{ // no pain_complain not smaller tan 2
        
          if (no_pain_complain == 5){
            decision = 1;
          }
          else{// no pain complain not 5
           
            if (no_pain_complain == 3 && no_pain_complain != 6 ){
           
              decision = 4;
            }
            else{ 
              decision = 7;
            }
         }
       }
     }
   }
 }
  
  
 return decision; 
 /*
   decision explains: 
   0 : error
   1 : prosthesis
   2 : endodontia
   3 : pedodontia
   4 : periodontia
   5 : surgery
   6 : radiology
   7 : orthodontia 
   8 : restorative
   9 : restorative + peridontia 
   10: endodontia + periodontia
   11: orthodontia + periodontia
   12: surgery +  periodontia
   13: radiology + periodontia
   14: prosthesis + periodontia
 
 */
}

int dt3b(double age , double brush_per_day, int pain , int film , int pain_complain , int no_pain_complain){


 int decision;

  if ( brush_per_day < 3 ){
     
     if(pain == 1){
      
       if(pain_complain < 4){
         
         if (film == 1){
           
           if (pain_complain == 3){
             decision = 10;
           }
           else{ //pain_complain not 3
             if (pain_complain>3){
               if(pain_complain<5){
                 decision = 9;
               }
               else{ // pain_complain0>5
                 if( pain_complain<6){
                  decision = 14;
                 }
                 else{//pain_complain = 6
                  decision = 0;
                 }
               }
              
             }
             else{ //pain_complain <= 3
              
               if( pain_complain<2){
                  decision = 10;
                 }
                 else{//pain_complain not smaller than 2 
                  decision = 12;
                 }
             }
           }
         }
         else{ // no film
           decision = 13;
         }
       }
       else{ //pain_complain<4 else
         if ( pain_complain == 5) { 
           decision = 14;
         }
         else{ //pain complain not 5
           if( pain_complain != 6){
              decision = 9;
           }
           else{
             decision = 0;
           }
         }
       }
     }
     else{ // if no pain
       if (age<16){
         decision = 3;
       }
       else{ // age not under 16
        if( no_pain_complain >1 && no_pain_complain<3){
           if (film == 1){
             decision = 12;
           }
           else{ // no film
             decision = 13;
           }
        }
        else{ // no_pain_complain not between 1 and 3
          if( no_pain_complain == 1 || no_pain_complain == 3){
             decision = 4;
          }
          else{ // no _pain_complain not 1 or 3
            if( no_pain_complain<5){
             decision = 11;
            }
            else{
              if(no_pain_complain !=6){
               decision = 14;
              }
              else{
               decision = 0;
              }
            }
          }
        }
       }
     }
    
  } 
  else{ // if brush more than 3
   if (pain == 1){
     if( pain_complain == 1 || pain_complain == 3){
             decision = 2;
      }
      else{ // pain not 1 or 3
        if ( pain_complain > 3){
          if( pain_complain != 6){
             if( pain_complain == 5 ){
              decision = 1;
             }
             else{ // pain_complain not 5
              decision = 8;
             }
          }
          else{ //  pain_complain = 6
           decision = 0;
          }
        }
        else{ //pain not bigger than 3
          if (film == 1){
            decision = 5;
          }
          else{ //no film
            decision = 6;
          }
        }
      }
          
         
   }
   else{ // no pain
     
     if ( no_pain_complain !=6){
        if(no_pain_complain == 2) {
          if (film == 1){
           decision = 5;
          }
          else{ // film 0
           decision = 6;
          }
          
        }
        else{ // no_pain_complain not = 2
          if(no_pain_complain <4){
            decision = 4;
          }
          else{ //no_pain_complain 4 or bigger
            if (no_pain_complain == 5){
              decision = 1;
            }
            else{ // no_pain_complain not 5
              decision = 7;
            }
          }
        }
     }
     else { // if no_pain_complain = 6
       decision = 0;
     }
   }
  
 }
  
  
 return decision; 
 /*
   decision explains: 
   0 : error
   1 : prosthesis
   2 : endodontia
   3 : pedodontia
   4 : periodontia
   5 : surgery
   6 : radiology
   7 : orthodontia 
   8 : restorative
   9 : restorative + peridontia 
   10: endodontia + periodontia
   11: orthodontia + periodontia
   12: surgery +  periodontia
   13: radiology + periodontia
   14: prosthesis + periodontia
 
 */
}




/* Provide your implementations for all the requested functions here */
