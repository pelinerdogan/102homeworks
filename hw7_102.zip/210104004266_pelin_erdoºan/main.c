#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

void printtable(char arr[15][15]);

int main(){

enum side{horizontallyLEFT ,horizontallyRIGHT ,verticallyTOP ,verticallyBOTTOM,diagonalyLEFTUP,diagonalyLEFTDOWN,diagonalyRIGHTUP,diagonalyRIGHTDOWN};
srand(time(NULL)); //to change randoms everytime
int randNum ,randNum2,randNum3,randNum4,randNum5 ; 
int life = 3;
int points = 0;
char alphabet[27] ="abcdefghijklmnopqrstuvwxyz";
char table[15][15];
char words[7][10];//to keep words
int rows[7];  //to keep row numbers
int columns[7];  //to keep column numbers
int road[7];   //to keep way word goes
int full[195];// to prevent words to intercept


 int sameWordCheck[7] = {0,0,0,0,0,0,0};
  for (int a =0;a<195;a++){
  
    full [a] = 0;
  
  }
  
  

//create table with random letters


for (int i = 0; i<15;i++){
    for(int k = 0;k<15;k++){
       randNum  = rand()%26;
       table[i][k] = alphabet[randNum];
        
    }
   
}


 


//put words in it

  FILE *ptr ;
  char trash[5];
  char word[5];
  ptr = fopen("wordlist.txt","r");
  
  for (int y = 0 ; y<7;y++){ // taking  8 random words  
     
     randNum2 = (rand()%50) +1;
     
     while(randNum2 == sameWordCheck[0] || randNum2 == sameWordCheck[1] || randNum2 == sameWordCheck[2] ||
randNum2 == sameWordCheck[3] || randNum2 == sameWordCheck[4] || randNum2 == sameWordCheck[5] || randNum2 == sameWordCheck[5]) {
          
          randNum2 = (rand()%50) +1;  //if there is 2 same words this changes
          
        

    }
     rewind(ptr); // to start file from beggining
     sameWordCheck[y] = randNum2; 
     
      for (int m= 1; m<51; m++){
  
       if(m == randNum2 && m<50){
   
        fscanf(ptr,"%s\n",words[y]);  //taking the word in line randNum2
        
    
   
   
       }
       if(m != randNum2 && m<50){
   
   
       fscanf(ptr,"%s\n",trash);
   
       }
  
  
      if(m == randNum2 && m==50){
   
      fscanf(ptr,"%s",words[y]);
   
  
   
      }
  
  
      if(m != randNum2 && m==50){
   
   
      fscanf(ptr,"%s",trash);
   
  
   
     }
  
  
  
  
   }
   
   
  
 }
   

   for (int j = 0; j<7;j++){
     int length = (int) strlen(words[j]);
     int written = 0;
     int loop = 0;
    
   
 
     int count2 = 0;
  
   
   
     loop = 0;
     count2 = 0;
     randNum3 = rand()%15;//row
     randNum4 = rand()%15;//column
     randNum5 = rand()%8;//placment
     
     
      switch(randNum5){
    
       case horizontallyLEFT :
        
        while(written == 0 && loop == 0){
       
         if(randNum4<=length-1){
          randNum4 = rand()%15;
         }
         else{
      
          for(int b = 0 ; b < length;b++){
       
            if(randNum4<=length-1){
             randNum4 = rand()%15;
            }
            else{
       
             if(full[(randNum3*15) + (randNum4-b)] == 0){
       
         
               table[randNum3][randNum4-b] = words[j][b];//moving right changing letters
               full[(randNum3*15) + (randNum4-b)] = 1;
               written=1;
        
               rows[j]=randNum3;
               columns[j] = randNum4;
               road[j]=randNum5;
         
         
       
              }
              else{
        
           
               b= -1;//start b from beggining
               written=0;
               randNum3 = rand()%15;//row
               randNum4 = rand()%15;//column
               count2++;
           
               if(count2>50){ //to prevent infinite situation
            
                loop = 1;
                 break;
           
               }
           
           
               for(int c = 0 ; c < b;c++){
         
               full[((randNum3)*15) + (randNum4-c)] = 0;
         
               randNum  = rand()%26;
               table[randNum3][randNum4-c] = alphabet[randNum];
         
         
               }
        
             }
        
           }
       
         }
       
      
      
        }
     
       }
    
    
      break;
     case  horizontallyRIGHT :
     
     
      while(written == 0 && loop == 0){
       
        if(randNum4 >= 16-length){
         randNum4 = rand()%15;
         }
        else{
      
          for(int b = 0 ; b < strlen(words[j]);b++){
            
            if(randNum4 >= 16-length){
             randNum4 = rand()%15;
             }
      
            else{
         
         
             if(full[(randNum3*15) + (randNum4+b)] == 0){
        
             full[(randNum3*15) + (randNum4+b)] = 1;
             table[randNum3][randNum4+b] = words[j][b];
         
       
             written=1;
             rows[j]=randNum3;
             road[j]=randNum5;
             columns[j] = randNum4;
         
            }
            else{
          
             b= -1;
             written=0;
          
             randNum3 = rand()%15;//row
             randNum4 = rand()%15;//column
             count2++;
           
             if(count2>50){
            
              loop = 1;
              break;
           
             }
            
             for(int c = 0 ; c <b;c++){
         
              full[((randNum3)*7) + (randNum4+c)] = 0;
         
              randNum  = rand()%26;
              table[randNum3][randNum4+c] = alphabet[randNum];
         
         
             }
         
            }
         }
         
         
        }
      
       }
     }
    
     break;
     
     case verticallyTOP :
     
    
     while(written == 0 && loop == 0){
     
      if(randNum3<=length-1){
        randNum3 = rand()%15;
      }
      else{
      
       for(int b = 0 ; b < strlen(words[j]);b++){
         if(randNum3<=length-1){
        randNum3 = rand()%15;
      }
      else{
      
         
         
         if(full[((randNum3-b)*15) + (randNum4)] == 0){
        
         table[randNum3-b][randNum4] = words[j][b];
         
        
         full[((randNum3-b)*15) + (randNum4)] = 1;
         written=1;
         rows[j]=randNum3;
         columns[j] = randNum4;
         road[j]=randNum5;
         
         
         }
         else{
         
           b= -1;
           written=0;
           randNum3 = rand()%15;//row
           randNum4 = rand()%15;//column
           count2++;
           if(count2>50){
            
           loop = 1;
           break;
           
           }
           
            for(int c = 0 ; c < b;c++){
         
            full[((randNum3-c)*15) + (randNum4)] = 0;
         
            randNum  = rand()%26;
            table[randNum3-c][randNum4] = alphabet[randNum];
         
         
            }
         
           }
         }
       }
       
      }
     
     }
     
     break;
     
     case verticallyBOTTOM :
     
     
     
     while(written == 0 && loop == 0){
       
       if(randNum3 >=16-length ){
         randNum3 = rand()%15;
        }
      else{
      
       for(int b = 0 ; b < length;b++){
       if(randNum3 >=16-length ){
        randNum3 = rand()%15;
      }
      else{
         
         
         if(full[((randNum3+b)*15) + (randNum4)] == 0){
         
         
         table[randNum3+b][randNum4] = words[j][b] ;
         
        
         full[((randNum3+b)*15) + (randNum4)] = 1;
         written=1;
         rows[j]=randNum3;
         road[j]=randNum5;
         columns[j] = randNum4;
         
         
         }
         else{
             
          
           
           written=0;
           randNum3 = rand()%15;//row
           randNum4 = rand()%15;//column
            b= -1;
            count2++;
           if(count2>50){
            
           loop = 1;
           break;
           
           }
           
          for(int c = 0 ; c < b;c++){
         
            full[((randNum3+c)*15) + (randNum4)] = 0;
         
            randNum  = rand()%26;
            table[randNum3+c][randNum4] =  alphabet[randNum];
         
         
          }
         
         }
        }
       }
       
      }
     }
     
     break;
     case diagonalyLEFTUP :
       
       while(written == 0 && loop == 0){
       
      
       
        for(int b = 0 ; b < strlen(words[j]);b++){
        
          if(randNum3>length-1  &&randNum4>length-1){
         
         
            if(full[((randNum3-b)*15) + (randNum4-b)] == 0){
         
          
         
          table[randNum3-b][randNum4-b] = words[j][b];
       
          full[((randNum3-b)*15) + (randNum4-b)] = 1;
         
          written=1;
          rows[j]=randNum3;
          columns[j] = randNum4;
          road[j]=randNum5; 
         
         }
         else{
         
         
          
            b= -1;
           written=0;
           randNum3 = rand()%15;//row
           randNum4 = rand()%15;//column
           count2++;
           
             if(count2>50){
            
             loop = 1;
             break;
           
           }
           
           for(int c = 0 ; c < b;c++){
         
            full[((randNum3-c)*15) + (randNum4-c)] = 0;
         
            randNum  = rand()%26;
            table[randNum3-c][randNum4-c] =  alphabet[randNum];
         
            }
         
         }
       }
       
      else{
       
        b=-1;
        randNum3 = rand()%15;
        randNum4 = rand()%15;
      
      
        }
       
       }
      
      
      } 
     
     
     break; 
     case diagonalyLEFTDOWN :
     
     
     
         while(written == 0 && loop == 0){
         
          
          
           for(int b = 0 ; b < strlen(words[j]);b++){
           if( randNum3<16-length && randNum4>length-1){
           
             
              if(full[((randNum3+b)*15) + (randNum4-b)] == 0){
               
                
                table[randNum3+b][randNum4-b] = words[j][b];
                full[((randNum3+b)*15) + (randNum4-b)] = 1;
                written=1;
                rows[j]=randNum3;
                columns[j] = randNum4;
                road[j]=randNum5; 
         
         
         }
         else{
           
            written=0;
            randNum3 = rand()%15;//row
            randNum4 = rand()%15;//column
            b= -1;
            count2++;
           
           if(count2>50){
            
             loop = 1;
             break;
           
           }
           
           for(int c = 0 ; c <b ;c++){
         
         full[((randNum3+c)*15) + (randNum4-c)] = 0;
         
         randNum  = rand()%26;
          table[randNum3+c][randNum4-c] =  alphabet[randNum];
         
         }
         
         
         }
       }
       
        
      else{
       
       
         b=-1;
        randNum3 = rand()%15;
        randNum4 = rand()%15;
      
      
      } 
       
      }
      }
     
     break;
     case  diagonalyRIGHTUP :
     
         while(written == 0 && loop == 0){
           
      
        for(int b = 0 ; b < strlen(words[j]);b++){
         if( randNum3>length-1 && randNum4< 16-length){
         
         
         
         if(full[((randNum3-b)*15) + (randNum4+b)] == 0){
         table[randNum3-b][randNum4+b] = words[j][b];
         
       
         full[((randNum3-b)*15) + (randNum4+b)] = 1;
         written=1;
         rows[j]=randNum3;
         columns[j] = randNum4;
         road[j]=randNum5; 
         
         
         }else{
         
           
           written=0;
           randNum3 = rand()%15;//row
           randNum4 = rand()%15;//column
           b = -1;
           count2++;
           
           if(count2>50){
            
           loop = 1;
           break;
           }
           for(int c = 0 ; c < b;c++){
         
         full[((randNum3-c)*15) + (randNum4+c)] = 0;
         
         randNum  = rand()%26;
          table[randNum3-c][randNum4+c] =  alphabet[randNum];
         
         
         }
         
         
         }
       }
       
            else{
       
       
          b=-1;
        randNum3 = rand()%15;
        randNum4 = rand()%15;
      
      
      } 
       
      }

      
      }
       
     break;
     case  diagonalyRIGHTDOWN :
     
     
       while(written == 0 && loop == 0){
     
        for(int b = 0 ; b < strlen(words[j]);b++){
          if(randNum3<16-length && randNum4< 16-length ){
        
         if(full[((randNum3+b)*15) + (randNum4+b)] == 0){
         
         table[randNum3+b][randNum4+b] = words[j][b];
         
      
         full[((randNum3+b)*15) + (randNum4+b)] = 1;
         written=1;
         rows[j]=randNum3;
         columns[j] = randNum4;
         road[j]=randNum5;
         
         
         }
         else{
         
           written=0;
           randNum3 = rand()%15;//row
           randNum4 = rand()%15;//column
           b=-1;
           count2++;
           if(count2>50){
            
           loop = 1;
           break;
           
           }
           for(int c = 0 ; c < b;c++){
         
            full[((randNum3+c)*15) + (randNum4+c)] = 0;
            randNum  = rand()%26;
            table[randNum3+c][randNum4+c] = alphabet[randNum];
         
         
         }
         
          
         }
       }
       
       else{
       
          b=-1;
        randNum3 = rand()%15;
        randNum4 = rand()%15;
      
      
      }  
       
      }
      
      
      }
    
     break;

    
    
    
    
    
    
    
    }
             
  
   
   
    
   
   
   }


   printtable(table);



    for(int k=0;k<7;k++)
      printf("%d %d %s\n" , rows[k],columns[k] ,words[k] );
      
      
//ask user
  int wordcount = 0;
  while(life >0)
  {
  int rowenter,columnenter; 
  char wordenter[10];
  char exit[3];

  
  printf("if you want to exit please type \":d\" if you want to keep playin type :) \n ");
  scanf("%s" , exit);
  
  if (strcmp(exit,":d")==0){
   
   life=0;
   printf("exiting...");
   
  }
  else{
  printf("Enter coordinates and word\n");
  
  scanf("%d %d %s" , &rowenter,&columnenter,wordenter);
  
  
  
  
//check user

   int control = 0; // going to control if any of the 7 words match with answer
   int wordchoosen;
   
    for(int m=0;m<7;m++){
     
      
      if(rows[m] == rowenter && columns[m] == columnenter){
        
        if(strcmp(words[m],wordenter) == 0){
           control = 1;
           wordchoosen = m;
        }
      
      }
   
    }
    
    if (control == 1){
     points=points+2;
     wordcount++;
     if(wordcount<7)
     printf("Founded! You got 2 points. Your total point is : %d:\n", points);
     if(wordcount==7){
     printf("WELL PLAYED! you found all words Your total point is : %d:\n", points);
     life = 0;
     }
     switch(road[wordchoosen]){
     
     
     case horizontallyLEFT :
       
       
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]][columns[wordchoosen]-b] = '*';
       
       
     break;
     case  horizontallyRIGHT :
     
      
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]][columns[wordchoosen]+b] = '*';
           
          
     break;
     case verticallyTOP :
     
        
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]-b][columns[wordchoosen]] = '*';
    
     break;
     case verticallyBOTTOM :
     
     
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]+b][columns[wordchoosen]] = '*';
     break;
     case diagonalyLEFTUP :
     
         
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]-b][columns[wordchoosen]-b] = '*';
     break;
     
     case  diagonalyLEFTDOWN :
         
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]+b][columns[wordchoosen]-b] = '*';
     
    
     break;
     
          
     case  diagonalyRIGHTDOWN :
         
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]+b][columns[wordchoosen]+b] = '*';
     
    
     break;


     
     case  diagonalyRIGHTUP :
         
        for(int b = 0 ; b < strlen(words[wordchoosen]);b++)
          table[rows[wordchoosen]-b][columns[wordchoosen]+b] = '*';
     
    
     break;

     
     
     
     }
     
     
       printtable(table);
     
     
     
     
     
     
     
     
     
     
   }
   else{
   
     life--;
     printf("Sorry that is not right. you have %d lifes left.\n" , life);
     if(life == 0)
       printf("Game over! Your total point is : %d:\n", points);
     
   }
  }
  }
}



void printtable(char arr[15][15]){

printf("\n");
printf("\n");



for (int i = 0; i<15;i++){

  printf("%d " , i);
  if(i<10)
   printf(" ");
    for(int k = 0;k<15;k++){
       printf("%c " , arr[i][k]);
    }
    printf("\n");
}









}
    
    